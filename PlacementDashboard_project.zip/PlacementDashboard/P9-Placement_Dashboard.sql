CREATE DATABASE PlacementDB;
GO

USE PlacementDB;
GO

CREATE TABLE Students
(
    StudentId INT PRIMARY KEY,
    EnrollmentNo VARCHAR(20) NOT NULL,
    StudentName VARCHAR(100) NOT NULL,
    Department VARCHAR(50) NOT NULL,
    PassingYear INT NOT NULL,
    IsPlaced BIT NOT NULL DEFAULT 0
);

CREATE TABLE Placements
(
    PlacementId INT PRIMARY KEY,
    StudentId INT NOT NULL UNIQUE,
    CompanyName VARCHAR(100) NOT NULL,
    JobRole VARCHAR(100) NOT NULL,
    PackageLPA DECIMAL(6,2) NOT NULL,
    FOREIGN KEY (StudentId) REFERENCES Students(StudentId)
);

INSERT INTO Students VALUES
(1, 'CE101', 'Kabir Sharma', 'CE', 2026, 1),
(2, 'CE102', 'Ananya Gupta', 'CE', 2026, 1),
(3, 'CE103', 'Rohan Verma', 'CE', 2026, 0),
(4, 'CE104', 'Sneha Nair', 'CE', 2026, 1),
(5, 'CE105', 'Yash Raval', 'CE', 2026, 1),
(6, 'CE106', 'Pooja Bhatt', 'CE', 2026, 0),
(7, 'CE107', 'Harsh Vora', 'CE', 2026, 1),
(8, 'CE108', 'Ishita Jain', 'CE', 2026, 1);

INSERT INTO Placements VALUES
(1, 1, 'Accenture', 'Associate Software Engineer', 4.50),
(2, 2, 'Capgemini', 'Analyst', 3.80),
(3, 4, 'Cognizant', 'Programmer Analyst', 4.20),
(4, 5, 'Zoho', 'Software Developer', 7.50),
(5, 7, 'LTIMindtree', 'Graduate Engineer Trainee', 4.00),
(6, 8, 'Tech Mahindra', 'Support Engineer', 3.25);
GO
